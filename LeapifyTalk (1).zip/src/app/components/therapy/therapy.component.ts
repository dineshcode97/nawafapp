import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-therapy',
  templateUrl: './therapy.component.html',
  styleUrls: ['./therapy.component.css']
})
export class TherapyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
