import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-t-and-c',
  templateUrl: './t-and-c.component.html',
  styleUrls: ['./t-and-c.component.css']
})
export class TAndCComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
