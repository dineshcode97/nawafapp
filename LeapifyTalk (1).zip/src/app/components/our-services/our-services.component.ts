import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-our-services',
  templateUrl: './our-services.component.html',
  styleUrls: ['./our-services.component.css']
})
export class OurServicesComponent implements OnInit {

  @ViewChild('serviceNav') serviceNav!: ElementRef;
  template: boolean[] = [ true, false,false,false,false ] 

  constructor() { }

  ngOnInit(): void {
  }

  switch(no: number){
    this.template = [false, false,false,false,false]
    this.template[no] = true;
  }

  slideLeft(){
    this.serviceNav.nativeElement.scrollLeft -=150;
    // $('#service').animate( { $('#service').scrollLeft-=150 }, 1000, 'ease' );
  }
  
  slideRight(){
    this.serviceNav.nativeElement.scrollLeft +=150;
    // $('#service').animate( { $('#service').scrollLeft: '+=150' }, 1000, 'ease' );
  }
}
