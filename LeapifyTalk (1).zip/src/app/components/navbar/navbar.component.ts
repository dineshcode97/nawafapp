import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  @ViewChild('toggle') toggle!: ElementRef;

  getStarted: boolean = false;

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    this.router.events.subscribe(val=>{
      if(this.router.url.startsWith("/get-started"))
        this.getStarted = true;
      else
        this.getStarted = false;
    }
    )
   
  }

  hide(){
    if(window.innerWidth < 976)
    this.toggle.nativeElement.click();
  }
}
