import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css']
})
export class PricingComponent implements OnInit {
  isSmall: boolean = false;

  constructor() { }

  ngOnInit(): void {
    this.carouselSwitch();
  }

  carouselSwitch(){
    if(window.innerWidth > 992)
      this.isSmall = false;
    else
      this.isSmall = true;
  }

}
