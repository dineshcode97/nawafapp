import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounselorJobComponent } from './counselor-job.component';

describe('CounselorJobComponent', () => {
  let component: CounselorJobComponent;
  let fixture: ComponentFixture<CounselorJobComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CounselorJobComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselorJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
