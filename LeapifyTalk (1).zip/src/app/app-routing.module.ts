import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CounselorJobComponent } from './components/counselor-job/counselor-job.component';
import { GetStartedComponent } from './components/get-started/get-started.component';
import { HomeComponent } from './components/home/home.component';
import { OurServicesComponent } from './components/our-services/our-services.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { ProviderComponent } from './components/provider/provider.component';
import { TAndCComponent } from './components/t-and-c/t-and-c.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'privacy-policy', component: PrivacyPolicyComponent },
  { path: 'counselor-job', component: CounselorJobComponent },
  { path: 'provider', component: ProviderComponent },
  { path: 'get-started', component: GetStartedComponent },
  { path: 'our-services', component: OurServicesComponent },
  { path: 'terms-and-conditions', component: TAndCComponent }
];

const options:ExtraOptions = { 
  scrollPositionRestoration: 'enabled',
anchorScrolling: 'enabled' 
};

@NgModule({
  imports: [RouterModule.forRoot(routes, options)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
