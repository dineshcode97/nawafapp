import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { TherapyComponent } from './components/therapy/therapy.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { ReviewsComponent } from './components/reviews/reviews.component';
import { FaqsComponent } from './components/faqs/faqs.component';
import { ProviderComponent } from './components/provider/provider.component';
import { TAndCComponent } from './components/t-and-c/t-and-c.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CounselorJobComponent } from './components/counselor-job/counselor-job.component';
import { GetStartedComponent } from './components/get-started/get-started.component';
import { FormsModule } from '@angular/forms';
import { FooterComponent } from './components/footer/footer.component';
import { OurServicesComponent } from './components/our-services/our-services.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    TherapyComponent,
    PricingComponent,
    ReviewsComponent,
    FaqsComponent,
    ProviderComponent,
    TAndCComponent,
    PrivacyPolicyComponent,
    ContactUsComponent,
    CounselorJobComponent,
    GetStartedComponent,
    FooterComponent,
    OurServicesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
